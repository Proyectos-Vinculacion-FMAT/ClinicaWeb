document.addEventListener("DOMContentLoaded", () => {
  // Función auxiliar para mostrar notificaciones en pantalla
  const showNotification = (message, type = 'info') => {
    const notif = document.createElement('div');
    notif.className = `notification notification-${type}`;
    notif.textContent = message;
    // Se puede ajustar la ubicación; en este ejemplo se agrega al final del body
    document.body.appendChild(notif);
    setTimeout(() => {
      notif.remove();
    }, 3000);
  };

  // ===============================
  // Citas: Filtrado
  // ===============================
  const setupCitasFiltering = () => {
    const filterBtn = document.getElementById('filter-btn');
    if (filterBtn) {
      filterBtn.addEventListener('click', () => {
        const searchValue = document.getElementById('search')?.value.trim().toLowerCase() || "";
        const dateValue = document.getElementById('date-filter')?.value || "";
        const serviceValue = document.getElementById('service-filter')?.value || "";

        console.log("Filtrando por:", searchValue, dateValue, serviceValue);

        // Ejemplo: filtrar filas de la tabla (por ahora, solo por paciente)
        const rows = document.querySelectorAll('.citas-list table tbody tr');
        rows.forEach(row => {
          const cells = row.getElementsByTagName('td');
          const paciente = (cells[1] ? cells[1].textContent.toLowerCase() : "");
          row.style.display = paciente.includes(searchValue) ? '' : 'none';
        });
      });
    }
  };

  // ===============================
  // Requerimientos
  // ===============================
  const setupRequerimientosForm = () => {
    const reqForm = document.getElementById('requerimiento-form');
    if (reqForm) {
      reqForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const descripcion = document.getElementById('descripcion').value;
        if (!descripcion.trim()) {
          showNotification("Por favor, ingresa una descripción para el requerimiento.", 'error');
          return;
        }
        console.log("Requerimiento enviado:", descripcion);
        showNotification("Requerimiento enviado correctamente. Se mostrará en el listado.", 'success');
        reqForm.reset();

        // Simulación de agregar una fila al listado
        const tbody = document.querySelector('.requerimientos-list table tbody');
        if (tbody) {
          const newRow = document.createElement('tr');
          newRow.innerHTML = `
            <td>R00X</td>
            <td>${descripcion}</td>
            <td>Pendiente</td>
            <td><a href="#" aria-label="Ver detalles del requerimiento">Ver Detalles</a></td>
          `;
          tbody.appendChild(newRow);
        }
      });
    }
  };

  // ===============================
  // Usuarios
  // ===============================
  const setupUsuariosForm = () => {
    const userForm = document.getElementById('usuario-form');
    if (userForm) {
      userForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const nombre = document.getElementById('nombre').value;
        const correo = document.getElementById('correo').value;
        const rol = document.getElementById('rol').value;
        if (!nombre.trim() || !correo.trim() || !rol) {
          showNotification("Por favor, completa todos los campos.", 'error');
          return;
        }
        console.log("Agregando usuario:", nombre, correo, rol);
        showNotification("Usuario agregado exitosamente.", 'success');
        userForm.reset();

        // Agregar nueva fila a la tabla
        const tbody = document.querySelector('.usuarios-list table tbody');
        if (tbody) {
          const newRow = document.createElement('tr');
          const userId = "U" + (tbody.children.length + 1).toString().padStart(3, "0");
          newRow.innerHTML = `
            <td>${userId}</td>
            <td>${nombre}</td>
            <td>${correo}</td>
            <td>${rol.charAt(0).toUpperCase() + rol.slice(1)}</td>
            <td><a href="#" aria-label="Editar usuario ${userId}">Editar</a> | <a href="#" aria-label="Eliminar usuario ${userId}">Eliminar</a></td>
          `;
          tbody.appendChild(newRow);
        }
      });
    }
  };

  // ===============================
  // Bloqueos
  // ===============================
  const setupBloqueosForm = () => {
    const bloqueoForm = document.getElementById('bloqueo-form');
    if (bloqueoForm) {
      bloqueoForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const establecimiento = document.getElementById('establecimiento').value;
        const consultorio = document.getElementById('consultorio').value;
        const fechaInicio = document.getElementById('fecha-inicio').value;
        const fechaFin = document.getElementById('fecha-fin').value;
        const descripcion = document.getElementById('descripcion').value;

        if (!establecimiento || !consultorio || !fechaInicio || !fechaFin || !descripcion) {
          showNotification("Por favor, completa todos los campos.", 'error');
          return;
        }
        console.log("Bloqueo agregado:", establecimiento, consultorio, fechaInicio, fechaFin, descripcion);
        showNotification("Bloqueo registrado correctamente.", 'success');
        bloqueoForm.reset();

        // Simulación de agregar nueva fila
        const tbody = document.querySelector('.bloqueos-list table tbody');
        if (tbody) {
          const bloqueosCount = tbody.children.length + 1;
          const bloqueoId = "B" + bloqueosCount.toString().padStart(3, "0");
          const newRow = document.createElement('tr');
          newRow.innerHTML = `
            <td>${bloqueoId}</td>
            <td>${establecimiento}</td>
            <td>${consultorio}</td>
            <td>${fechaInicio}</td>
            <td>${fechaFin}</td>
            <td>${descripcion}</td>
            <td><a href="#" class="liberar-bloqueo" aria-label="Liberar bloqueo ${bloqueoId}">Liberar</a></td>
          `;
          tbody.appendChild(newRow);
        }
      });
    }
  };

  const setupLiberarBloqueos = () => {
    document.addEventListener('click', (e) => {
      if (e.target && e.target.classList.contains('liberar-bloqueo')) {
        e.preventDefault();
        if (confirm("¿Estás seguro de liberar este bloqueo?")) {
          const row = e.target.closest('tr');
          if (row) {
            row.remove();
            showNotification("Bloqueo liberado.", 'success');
          }
        }
      }
    });
  };

  // ===============================
  // Configuración: Notificaciones
  // ===============================
  const setupNotificacionesForm = () => {
    const notificacionesForm = document.getElementById('notificaciones-form');
    if (notificacionesForm) {
      notificacionesForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const canal = document.getElementById('canal').value;
        const frecuencia = document.getElementById('frecuencia').value;
        const mensaje = document.getElementById('mensaje').value;
        if (!canal || !frecuencia.trim() || !mensaje.trim()) {
          showNotification("Por favor, completa todos los campos de Notificaciones.", 'error');
          return;
        }
        console.log("Notificaciones guardadas:", canal, frecuencia, mensaje);
        showNotification("Configuración de notificaciones guardada correctamente.", 'success');
        notificacionesForm.reset();
      });
    }
  };

  // ===============================
  // Configuración: Reglas
  // ===============================
  const setupReglasForm = () => {
    const reglasForm = document.getElementById('reglas-form');
    if (reglasForm) {
      reglasForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const tiempoEspera = document.getElementById('tiempo-espera').value;
        const maxCitas = document.getElementById('max-citas').value;
        if (!tiempoEspera || !maxCitas) {
          showNotification("Por favor, completa todos los campos de Reglas.", 'error');
          return;
        }
        console.log("Reglas guardadas:", tiempoEspera, maxCitas);
        showNotification("Configuración de reglas guardada correctamente.", 'success');
        reglasForm.reset();
      });
    }
  };

  // ===============================
  // Configuración: Integración
  // ===============================
  const setupIntegracionForm = () => {
    const integracionForm = document.getElementById('integracion-form');
    if (integracionForm) {
      integracionForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const sistema = document.getElementById('sistema').value;
        const url = document.getElementById('url').value;
        const credenciales = document.getElementById('credenciales').value;
        if (!sistema || !url.trim() || !credenciales.trim()) {
          showNotification("Por favor, completa todos los campos de Integración.", 'error');
          return;
        }
        console.log("Integración guardada:", sistema, url, credenciales);
        showNotification("Configuración de integración guardada correctamente.", 'success');
        integracionForm.reset();
      });
    }
  };

  // ===============================
  // Función principal de interacciones
  // ===============================
  const initInteractions = () => {
    setupCitasFiltering();
    setupBloqueosForm();
    setupLiberarBloqueos();
    setupRequerimientosForm();
    setupUsuariosForm();
    setupNotificacionesForm();
    setupReglasForm();
    setupIntegracionForm();
    console.log("Interacciones inicializadas en interactions.js");
  };

  // Ejecutar la inicialización de interacciones
  initInteractions();
});
