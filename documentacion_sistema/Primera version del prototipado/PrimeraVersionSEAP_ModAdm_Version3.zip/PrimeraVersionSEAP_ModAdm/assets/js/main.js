/**
 * main.js
 * 
 * - Carga dinámica de componentes (header, sidebar, footer) de forma asíncrona.
 * - Función init() que se ejecuta cuando el DOM está listo.
 */

/**
 * Carga un archivo HTML en un contenedor específico (por ID) usando async/await.
 * @param {string} id - ID del contenedor en el DOM.
 * @param {string} filePath - Ruta del archivo HTML a cargar.
 */
const loadComponent = async (id, filePath) => {
  try {
    const response = await fetch(filePath);
    if (!response.ok) {
      throw new Error(`Error al cargar ${filePath}`);
    }
    const data = await response.text();
    const container = document.getElementById(id);
    if (container) {
      container.innerHTML = data;
    }
  } catch (error) {
    console.error('Error:', error);
  }
};

/**
 * Carga los componentes comunes (header, sidebar y footer) en paralelo.
 */
const initializeComponents = async () => {
  await Promise.all([
    loadComponent('header-container', 'components/header.html'),
    loadComponent('sidebar-container', 'components/sidebar.html'),
    loadComponent('footer-container', 'components/footer.html')
  ]);
};

/**
 * Inicializa la aplicación.
 * - Carga componentes globales.
 * - Se pueden incluir otras inicializaciones adicionales aquí.
 */
const init = async () => {
  await initializeComponents();
  console.log("Proyecto iniciado: componentes cargados desde main.js");
};

// Ejecutar init() cuando el DOM haya cargado por completo.
document.addEventListener("DOMContentLoaded", init);
